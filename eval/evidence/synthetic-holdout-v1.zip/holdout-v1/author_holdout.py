"""Author synthetic, model-blind retrieval fixtures; never import evaluation scores.

The prose is explicitly authored below, not generated from the retriever, its
rankings, or any model-generated answer. Execute once to serialize and audit.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = []


def case(group, slug, query, positive, negative, reason, tags, positive2=None):
    CASES.append(dict(group=group, slug=slug, query=query, positive=positive,
                      negative=negative, reason=reason, tags=tags,
                      positive2=positive2))


# English query -> English document. No query or fact is a translation of a
# case in another group: the four language groups have different entities.
case('en_en', 'canoe-deadline',
     'Can a canoe booking be moved for free when the trip starts in 36 hours?',
     'Canoe hire: changing the departure date has no fee at least 48 hours before launch. Inside that window, a date change costs 12 credits.',
     'Canoe hire: cancelling the booking has no fee at least 24 hours before launch. Later cancellations cost 12 credits.',
     'The request is a date change, not cancellation; 36 hours is less than the required 48 hours of notice, so changing the date costs 12 credits.',
     ['numeric_constraint', 'near_duplicate', 'intent_distinction'])
case('en_en', 'ceramics-eligibility',
     'Which pottery session lets a 13-year-old attend without an adult?',
     'Studio Juniper offers Independent Clay for ages 12 through 15; participants work without a guardian in the room.',
     'Studio Juniper offers Family Clay for ages 8 through 15; every participant must be accompanied by a guardian.',
     'Only Independent Clay satisfies both age 13 and no accompanying adult.',
     ['conjunction', 'numeric_constraint', 'paraphrase'])
case('en_en', 'sensor-code',
     'What should I do if the humidity sensor reports H-204 rather than H-240?',
     'Humidity sensor code H-204 indicates condensation on the probe. Disconnect power and let the probe dry before restarting.',
     'Humidity sensor code H-240 indicates a depleted backup cell. Replace the cell before restarting.',
     'H-204 is the required identifier; H-240 is a deliberately similar but different code.',
     ['exact_identifier', 'near_duplicate', 'lexical'])
case('en_en', 'stolen-badge',
     'Someone took my staff entry card. How do I stop it opening the building?',
     'A missing or stolen employee access badge must be deactivated through the security desk immediately. A replacement can be collected after identity verification.',
     'An employee access badge that is bent or unreadable can be exchanged at reception. Keep the old badge active until the exchange is complete.',
     'A stolen card requires deactivation; the damaged-card exchange procedure does not stop access.',
     ['paraphrase', 'security', 'intent_distinction'])
case('en_en', 'freezer-duration',
     'For the seed archive freezer, how long is a temperature excursion allowed before samples must be transferred?',
     'Seed archive freezer: if the temperature remains above minus 15 degrees Celsius for 30 consecutive minutes, transfer the seed trays to the reserve unit.',
     'Seed archive freezer: record a temperature reading every 30 seconds during an excursion. The measurement interval is not a transfer threshold.',
     'The transfer threshold is 30 minutes; the seconds value is only a sampling interval.',
     ['units', 'numeric_constraint', 'hard_negative'])
case('en_en', 'returns-exception',
     'Does the tool shop accept a return after I have opened a pack of safety masks?',
     'The tool shop accepts unused tools within 21 days. For hygiene reasons, safety masks are returnable only while the factory seal is intact.',
     'The tool shop accepts unused drill bits within 21 days even when their outer packaging has been opened.',
     'The mask-specific intact-seal exception applies, rather than the drill-bit packaging rule.',
     ['negation_exception', 'scope'])
case('en_en', 'printer-sequence',
     'Before loading fresh resin into the workshop printer, what preparation is required?',
     'Workshop resin printer refill procedure: first drain the old resin and clean the vat. Then load the fresh resin and run calibration.',
     'Workshop resin printer shutdown procedure: leave the vat filled, close the cover, and disconnect power. No calibration is needed for shutdown.',
     'The requested pre-refill steps are draining and cleaning; the shutdown instructions are a different operation.',
     ['sequence', 'procedure'])
case('en_en', 'current-lending',
     'Under the camera library rules effective from March 2028, how many lenses can one member borrow?',
     'Camera library rules effective 1 March 2028: a member may borrow three lenses at once. This replaces the prior two-lens limit.',
     'Archived camera library rules, valid through February 2028: a member may borrow two lenses at once.',
     'The effective-date qualifier selects the new rule rather than the explicitly archived rule.',
     ['temporal_version', 'numeric_constraint'])
case('en_en', 'compost-smell',
     'My worm bin reeks and feels soggy. What should I change?',
     'A vermicomposting bin with excess moisture and a sour odor needs dry shredded cardboard mixed into the bedding. Pause liquid food scraps until the bedding is merely damp.',
     'A vermicomposting bin with dry bedding and little worm activity needs a light mist of water. Do not add dry cardboard to already dry bedding.',
     'Wet, smelly bedding matches excess moisture, whereas the distractor concerns dryness.',
     ['colloquial', 'paraphrase', 'opposite_condition'])
case('en_en', 'abbreviation',
     'In the mobile planetarium checklist, what does the UPS keep running during a power cut?',
     'The mobile planetarium uninterruptible power supply keeps the control laptop and emergency aisle lights running for ten minutes. The projector is not on backup power.',
     'The mobile planetarium ultraviolet protection screen shields the transport case from sunlight. It supplies no electricity.',
     'UPS refers to the uninterruptible power supply and its backed-up devices, not the similarly initialled screen.',
     ['abbreviation', 'negation_exception', 'semantic'])
case('en_en', 'market-access',
     'For running a food stall at the orchard market, which registration document and food-handling document do I need?',
     'Orchard market stall application: every seller must provide the completed vendor registration form before a stall can be assigned.',
     'Orchard market visitors can download a parking map. Visitor parking does not require a vendor registration form or food-handling documentation.',
     'The question requests two independent required documents. One relevant record covers registration and the other covers food-handling certification.',
     ['multi_relevant', 'conjunction'],
     positive2='Orchard market food stalls: sellers must provide a current food-handling training certificate in addition to the stall application.')
case('en_en', 'van-choice',
     'Which removal van can take 800 kilograms and fit beneath a 2.4 metre entrance?',
     'Moving fleet: the Shortline van carries up to 900 kilograms and is 2.3 metres tall.',
     'Moving fleet: the Tallline van carries up to 1200 kilograms and is 2.7 metres tall.',
     'Only Shortline satisfies both payload and height; greater payload alone does not make Tallline suitable.',
     ['comparison', 'conjunction', 'units'])
case('en_en', 'file-extension',
     'Where should an invoice ending in .csv be placed for automatic import?',
     'For automatic invoice import, place comma-separated value files in the incoming-data folder. The importer watches that folder for CSV data files.',
     'For manual invoice review, place PDF copies in the review-documents folder. That folder is not watched by the automatic importer.',
     'The .csv extension and automatic-import intent select incoming-data, not manual PDF review.',
     ['punctuation', 'file_format', 'abbreviation'])
case('en_en', 'reminder-optout',
     'How do I stop book-club reminder emails but keep the monthly reading list?',
     'Book-club email preferences have separate toggles. Turn off Meeting Reminders and leave Reading List enabled to retain only the monthly selections.',
     'The book-club Unsubscribe All link disables both meeting reminders and the monthly reading list.',
     'The requested selective opt-out preserves the reading list; unsubscribe-all violates that constraint.',
     ['negation_exception', 'conjunction', 'intent_distinction'])
case('en_en', 'repair-vs-replace',
     'The theatre seat has a loose bolt but the frame is intact. Is a whole-seat replacement required?',
     'Theatre maintenance: tighten a loose seat bolt and verify the specified torque when the surrounding frame is undamaged. Replacement is unnecessary in that case.',
     'Theatre maintenance: replace the entire seat when the metal frame is cracked. Tightening the bolts is not an approved repair for a cracked frame.',
     'An intact frame and loose bolt meet the repair condition, not the cracked-frame replacement condition.',
     ['conditional', 'hard_negative', 'paraphrase'])
case('en_en', 'room-scope',
     'May visitors take photos inside the textile conservation room?',
     'Textile conservation room: photography is prohibited, including on mobile phones, because unfinished restoration work is confidential.',
     'Museum public galleries: photography without flash is permitted.',
     'The named conservation room has a specific prohibition; the general gallery rule has a different scope.',
     ['scope', 'negation_exception'])

# Chinese query -> Chinese document.
case('zh_zh', 'bike-reschedule',
     '自行车维修预约还有十八个小时，改时间要收费吗？',
     '自行车维修预约：距离原定时间至少二十四小时可免费改期；不足二十四小时，改期收取八元服务费。',
     '自行车维修预约：距离原定时间至少十二小时可免费取消；不足十二小时，取消收取八元服务费。',
     '询问的是改期，十八小时未达到二十四小时的免费门槛，不能套用取消规则。',
     ['numeric_constraint', 'near_duplicate', 'intent_distinction'])
case('zh_zh', 'choir-eligibility',
     '十六岁、没学过乐理的人，可以报名哪个合唱班？',
     '晨风合唱入门班面向十五岁及以上学员，不要求乐理基础。',
     '晨风合唱提高班面向十五岁及以上学员，报名者必须通过乐理入门考试。',
     '只有入门班同时满足年龄和无乐理基础两个条件。',
     ['conjunction', 'numeric_constraint', 'paraphrase'])
case('zh_zh', 'gate-code',
     '仓库门禁出现 E-731 该怎么处理？不要 E-713 的办法。',
     '仓库门禁故障 E-731 表示门磁未闭合，应清除门缝异物并确认门扇关紧。',
     '仓库门禁故障 E-713 表示读卡器离线，应检查网线与网络交换机端口。',
     'E-731 与 E-713 是不同故障码，查询明确排除了后者。',
     ['exact_identifier', 'near_duplicate', 'lexical'])
case('zh_zh', 'leaked-invite',
     '展览后台的邀请码被贴到公开群里了，怎样让别人不能再用它？',
     '展览后台邀请码一旦泄露，应在管理页撤销该邀请码，然后为获准成员生成新码。',
     '展览后台邀请码尚未泄露但即将到期时，可在管理页延长原码有效期，无需生成新码。',
     '公开泄露需要撤销旧码；延长有效期只适用于未泄露的情形。',
     ['paraphrase', 'security', 'intent_distinction'])
case('zh_zh', 'aquarium-duration',
     '水族馆检疫池的循环泵停了多久，才必须转移鱼？',
     '水族馆检疫池规定：循环泵连续停机四十分钟时，必须将鱼转移到备用池。',
     '水族馆检疫池规定：循环泵停机期间每四十秒记录一次溶氧读数；记录频率不等于转移标准。',
     '转移阈值为四十分钟，四十秒是检测间隔。',
     ['units', 'numeric_constraint', 'hard_negative'])
case('zh_zh', 'tea-return',
     '茶叶店的散装茶买回去后还能退吗？',
     '青岚茶铺退货规则：原封礼盒七日内可退；按重量分装的散茶售出后不退。',
     '青岚茶铺茶具退货规则：未使用的茶杯七日内可退，即使已拆除外包装。',
     '散茶有明确不退的例外，与礼盒或茶具的规则不同。',
     ['negation_exception', 'scope'])
case('zh_zh', 'telescope-sequence',
     '给观测站望远镜安装相机之前，先要做什么？',
     '观测站望远镜安装相机的顺序：先锁住赤道仪，再装配重，最后连接相机。',
     '观测站望远镜拆除相机的顺序：先卸下相机，再取配重，最后解除赤道仪锁定。',
     '安装前要锁赤道仪并装配重；不能把拆除顺序当作安装顺序。',
     ['sequence', 'procedure'])
case('zh_zh', 'current-locker',
     '按照二〇二九年一月起的规则，游泳馆储物柜能免费使用多久？',
     '游泳馆现行储物柜规则自二〇二九年一月一日起执行：免费使用九十分钟，之后按半小时计费。',
     '游泳馆已停用的储物柜规则适用于二〇二八年十二月以前：免费使用一百二十分钟。',
     '查询指定二〇二九年起的新规则，旧的一百二十分钟不适用。',
     ['temporal_version', 'numeric_constraint'])
case('zh_zh', 'sourdough-sour',
     '面包发酵种闻着刺鼻又很久不起泡，怎么救？',
     '发酵种酸味过重且活性下降时，取少量旧种，用较高比例的新面粉和水连续喂养两轮。',
     '发酵种膨胀旺盛、气泡充足时，可按原比例正常喂养，不必提高新面粉的比例。',
     '刺鼻、没有气泡对应过酸且活性下降，不是正常活跃状态。',
     ['colloquial', 'paraphrase', 'opposite_condition'])
case('zh_zh', 'loan-abbreviation',
     '读者借书页面上的 ILL 服务是什么意思？',
     '馆际互借服务允许读者申请本馆没有、但合作图书馆持有的图书，送达后在本馆取书。页面以 ILL 标示此服务。',
     '馆内续借服务只延长已经借出的本馆图书期限，不会从合作图书馆调书。',
     'ILL 指馆际互借，不是馆内续借。',
     ['abbreviation', 'semantic'])
case('zh_zh', 'roof-garden',
     '屋顶菜园新成员要交哪张申请表、参加哪项培训？',
     '屋顶菜园加入手续：新成员必须提交种植地块申请表，由管理员分配地块。',
     '屋顶菜园开放日的参观者只需领取导览图，不办理成员申请，也不领取种植地块。',
     '申请表与安全培训分属两份记录，两个正例各回答查询的一部分。',
     ['multi_relevant', 'conjunction'],
     positive2='屋顶菜园成员安全要求：获分配地块前，新成员必须参加雨水储罐安全培训。')
case('zh_zh', 'table-choice',
     '要放一台重七十公斤、底面宽一百厘米的设备，底面必须完全由台面支撑，选哪张工作台？',
     '实验室宽台的承重上限为八十公斤，台面宽一百一十厘米。',
     '实验室窄台的承重上限为一百公斤，台面宽八十厘米。',
     '只有宽台同时满足重量和宽度；窄台虽承重足够但台面太窄。',
     ['comparison', 'conjunction', 'units'])
case('zh_zh', 'audio-format',
     '录音以 .wav 结尾，应该放到哪个目录让节目系统自动读取？',
     '节目系统自动读取目录为 audio-in，该目录接受 WAV 无损音频文件。',
     '节目系统稿件审阅目录为 script-review，只存放文字稿，不自动读取音频。',
     '音频格式和自动读取需求对应 audio-in，不是稿件审阅目录。',
     ['punctuation', 'file_format', 'lexical'])
case('zh_zh', 'fitness-optout',
     '健身中心的促销短信能停掉，但预约提醒继续收吗？',
     '健身中心消息设置中，可单独关闭优惠推广短信并保留课程预约提醒，两项设置相互独立。',
     '健身中心的停用全部短信按钮会同时关闭优惠推广与课程预约提醒。',
     '需要选择性关闭推广，全部停用会违反保留预约提醒的要求。',
     ['negation_exception', 'conjunction', 'intent_distinction'])
case('zh_zh', 'tent-repair',
     '帐篷只是拉链卡住，布料没破，必须换整顶吗？',
     '营地装备维护：帐篷布料完好但拉链卡住时，先清除齿间沙粒并润滑拉链，不必更换整顶帐篷。',
     '营地装备维护：帐篷承力接缝发生长裂口时，应停止使用并更换帐篷，润滑拉链不能修复接缝。',
     '查询是完好布料上的拉链问题，不能套用承力接缝开裂的更换规则。',
     ['conditional', 'hard_negative', 'paraphrase'])
case('zh_zh', 'archive-scope',
     '地方档案馆的手稿阅览室里允许喝水吗？',
     '地方档案馆手稿阅览室禁止带入饮用水和其他液体，密封水瓶也不例外。',
     '地方档案馆大厅允许饮用密封水瓶里的水。',
     '手稿阅览室有独立的全面禁液体规定，大厅许可不能扩展过去。',
     ['scope', 'negation_exception'])

# Chinese query -> English document.
case('zh_en', 'ferry-change',
     '渡轮出发前三十个小时改签，还在免费改签的期限内吗？',
     'Ferry tickets may be rescheduled without a fee until 36 hours before departure. A later reschedule costs six credits.',
     'Ferry tickets may be cancelled without a fee until 24 hours before departure. A later cancellation costs six credits.',
     'Thirty hours fails the 36-hour rescheduling threshold; the 24-hour cancellation threshold concerns a different action.',
     ['cross_language', 'numeric_constraint', 'intent_distinction'])
case('zh_en', 'coding-eligibility',
     '十一岁而且不会编程的孩子，能参加哪个机器人班？',
     'The beginner robotics club accepts children aged ten to twelve and assumes no previous programming experience.',
     'The advanced robotics club accepts children aged ten to twelve but requires a completed introductory programming course.',
     'Only the beginner club satisfies both the age and lack of programming experience.',
     ['cross_language', 'conjunction', 'numeric_constraint'])
case('zh_en', 'lift-code',
     '货梯显示 L-508 时应该检查什么？',
     'Freight lift error L-508 means the platform load sensor is disconnected. Inspect the sensor cable before returning the lift to service.',
     'Freight lift error L-580 means the landing door is open. Close the landing door before returning the lift to service.',
     'L-508 identifies the disconnected load sensor, not the similarly numbered door-open code.',
     ['cross_language', 'exact_identifier', 'lexical_anchor'])
case('zh_en', 'shared-link',
     '志愿者排班表的共享链接被陌生人拿到了，怎样让旧链接失效？',
     'If a volunteer rota sharing link is exposed to outsiders, revoke the link in the sharing panel and issue a new one to approved volunteers.',
     'If a volunteer rota sharing link is about to expire but has not been exposed, extend its expiry date in the sharing panel.',
     'An exposed link requires revocation, not an extension of the same link.',
     ['cross_language', 'paraphrase', 'security'])
case('zh_en', 'incubator-duration',
     '育苗箱湿度过低持续多久，才要把苗盘移走？',
     'Seedling cabinet protocol: move the trays to the reserve cabinet after relative humidity has remained below 35 percent for twenty consecutive minutes.',
     'Seedling cabinet protocol: while humidity is low, record the reading every twenty seconds. Recording frequency is not the transfer threshold.',
     'The question asks the transfer duration, which is twenty minutes, not the twenty-second recording interval.',
     ['cross_language', 'units', 'numeric_constraint'])
case('zh_en', 'fabric-return',
     '布店已经按我要求裁好的布，还能按普通退货规定退吗？',
     'The fabric shop allows unused sealed sewing kits to be returned within fourteen days. Fabric cut to a requested length is excluded from returns.',
     'The fabric shop allows unused scissors to be returned within fourteen days even if the cardboard sleeve has been removed.',
     'The cut-to-length fabric exception directly answers the question; the scissors rule cannot override it.',
     ['cross_language', 'negation_exception', 'scope'])
case('zh_en', 'press-sequence',
     '更换印刷机滚筒之前，需要按什么顺序准备？',
     'Before replacing the print press roller, isolate electrical power, release the spring tension, and then open the roller housing.',
     'After replacing the print press roller, close the housing, restore spring tension, and then reconnect electrical power.',
     'The query asks pre-replacement steps; the distractor describes the reverse, post-replacement sequence.',
     ['cross_language', 'sequence', 'procedure'])
case('zh_en', 'current-storage',
     '从二〇二八年九月开始，舞蹈学校允许学员把鞋柜占用几天？',
     'Dance school locker rules effective September 2028 allow personal shoes to remain for four days. This supersedes the previous two-day allowance.',
     'Archived dance school locker rules effective before September 2028 allowed personal shoes to remain for two days.',
     'The date selects the four-day current rule rather than the superseded two-day rule.',
     ['cross_language', 'temporal_version', 'numeric_constraint'])
case('zh_en', 'plant-droop',
     '我的盆栽土还是湿的，叶子却蔫了发黄，还要继续浇水吗？',
     'Yellow, wilting leaves with persistently wet potting soil can indicate waterlogged roots. Stop watering temporarily and check that the drainage holes are clear.',
     'Wilting leaves with dry potting soil call for thorough watering until excess water drains from the bottom of the pot.',
     'Wet soil distinguishes waterlogging from the dry-soil watering advice.',
     ['cross_language', 'colloquial', 'opposite_condition'])
case('zh_en', 'abbreviation',
     '社区机房说明中的不断电供电设备，会保护哪些东西？',
     'The community server room UPS powers the network switch and storage array during short outages. The air-conditioning unit is not connected to it.',
     'The community server room ventilation controller regulates air flow during normal operation. It cannot supply backup electricity during an outage.',
     '不断电供电设备 maps to UPS; the positive specifies backed-up equipment, unlike the ventilation controller.',
     ['cross_language', 'abbreviation', 'semantic'])
case('zh_en', 'festival-permits',
     '参加河畔灯会摆摊并使用场地供电，需要哪种经营申请和哪种用电证明？',
     'Riverside lantern festival stalls require a completed temporary trader application before a stall location is assigned.',
     'Riverside lantern festival guests may collect an event map at the entrance. Guest admission does not authorize operating a stall.',
     'The trader application and electrical safety certificate are separate required documents, each supplied by a different relevant record.',
     ['cross_language', 'multi_relevant', 'conjunction'],
     positive2='Riverside lantern festival powered stalls must submit a valid portable-appliance inspection certificate before connection to site electricity.')
case('zh_en', 'coolbox-choice',
     '需要至少六升的内部容积、而且空箱重量不能超过四公斤，该用哪款实验室冷藏箱？',
     'The Compact laboratory coolbox has a seven-litre internal capacity and an empty weight of 3.8 kilograms.',
     'The Expedition laboratory coolbox has a twelve-litre internal capacity and an empty weight of 6.5 kilograms.',
     'Only Compact satisfies both at least six litres of capacity and no more than four kilograms of empty weight.',
     ['cross_language', 'comparison', 'units'])
case('zh_en', 'image-format',
     '要让扫描程序自动导入 .tiff 图片，该存到什么文件夹？',
     'The scanning pipeline watches the raster-drop folder for TIFF image files and imports them automatically.',
     'The scanning pipeline keeps PDF review copies in the manual-review folder. Files there are not imported automatically.',
     'The TIFF format and automatic-import intent select raster-drop, not manual-review.',
     ['cross_language', 'punctuation', 'file_format', 'lexical_anchor'])
case('zh_en', 'sports-optout',
     '运动社团的广告邮件想停，但比赛时间变动通知要保留，怎么设置？',
     'Sports club notification preferences allow Promotions to be turned off while Fixture Changes stays enabled. The two switches are independent.',
     'The sports club Stop All Email action disables promotions and fixture-change notices together.',
     'Selective controls preserve fixture changes; stopping all email violates the requested constraint.',
     ['cross_language', 'negation_exception', 'conjunction'])
case('zh_en', 'book-repair',
     '图书只是书脊外面的布松了，书页都还牢固，要重新装订吗？',
     'Library repair guidance: when only the outer spine cloth is loose and the text block is secure, reattach the cloth with archival adhesive; full rebinding is unnecessary.',
     'Library repair guidance: a detached text block with loose signatures requires full rebinding. Adhesive on the outer spine cloth is insufficient.',
     'The intact text block selects the minor cloth repair, not rebinding for a detached text block.',
     ['cross_language', 'conditional', 'paraphrase'])
case('zh_en', 'greenhouse-scope',
     '在植物园的繁育温室里，参观者可以摸植物吗？',
     'The propagation greenhouse is hands-off: visitors must not touch any plants or growing trays because young specimens are easily damaged.',
     'In the botanical garden sensory trail, visitors are encouraged to touch the designated aromatic plants.',
     'The greenhouse-specific prohibition governs the location, rather than the sensory-trail permission.',
     ['cross_language', 'scope', 'negation_exception'])

# English query -> Chinese document.
case('en_zh', 'kayak-change',
     'My kayak lesson starts in fifty hours. Is changing the date still free?',
     '皮划艇课程改期规则：至少提前七十二小时改期免费，晚于这一期限改期需支付十元。',
     '皮划艇课程取消规则：至少提前四十八小时取消免费，晚于这一期限取消需支付十元。',
     'Fifty hours fails the 72-hour rescheduling cutoff even though it meets the unrelated 48-hour cancellation cutoff.',
     ['cross_language', 'numeric_constraint', 'intent_distinction'])
case('en_zh', 'woodwork-eligibility',
     'Which woodworking class can a seventeen-year-old with no prior experience join?',
     '木工基础班接受十六岁及以上学员，无需木工经验，第一课教授手工具安全。',
     '木工进阶班接受十六岁及以上学员，必须先完成基础班并通过操作考核。',
     'Only the introductory class satisfies both the age and the no-experience condition.',
     ['cross_language', 'conjunction', 'numeric_constraint'])
case('en_zh', 'scanner-code',
     'What does barcode scanner fault S-062 require me to check?',
     '条码扫描器故障 S-062 表示镜头遮挡，应清洁镜头并移除保护膜。',
     '条码扫描器故障 S-026 表示数据线未连接，应重新插紧数据线。',
     'S-062 is a blocked lens; the similarly numbered S-026 is a cable fault.',
     ['cross_language', 'exact_identifier', 'lexical_anchor'])
case('en_zh', 'exposed-pass',
     'A photo of the rehearsal-room door pass was posted publicly. How can we stop the old pass from working?',
     '排练室电子通行证一旦公开泄露，应立即在管理界面作废原通行证，再为获准人员签发新证。',
     '排练室电子通行证尚未泄露但即将到期时，可以延长原通行证的有效期。',
     'Public exposure requires revoking the old pass; extending its expiry does not stop it working.',
     ['cross_language', 'paraphrase', 'security'])
case('en_zh', 'culture-duration',
     'How long may the mushroom growing room remain too hot before the trays need moving?',
     '蘑菇培育室温度连续高于二十八摄氏度达十五分钟时，应把菌盘移到备用培育室。',
     '蘑菇培育室出现高温后，每十五秒记录一次温度；记录间隔并不是菌盘转移阈值。',
     'The transfer threshold is fifteen minutes, not the fifteen-second logging interval.',
     ['cross_language', 'units', 'numeric_constraint'])
case('en_zh', 'engraved-return',
     'Can a trophy with a custom name engraving be returned under the normal returns policy?',
     '奖杯店退货规则：未刻字的现货奖杯在十日内可退；已按顾客要求刻字的奖杯不接受退货。',
     '奖杯店展示底座退货规则：未使用的底座十日内可退，即使外盒已打开。',
     'Custom engraving is the explicit exception; the display-base return policy has a different scope.',
     ['cross_language', 'negation_exception', 'scope'])
case('en_zh', 'pump-sequence',
     'What must be done before opening the irrigation pump to replace its filter?',
     '更换灌溉泵滤芯前，应先关闭电源，再关闭进水阀，排空泵内积水后才能打开泵壳。',
     '更换灌溉泵滤芯后，应合上泵壳，打开进水阀，确认充水完成再接通电源。',
     'The question asks before opening the pump; the positive supplies isolation and draining, while the distractor is the restart sequence.',
     ['cross_language', 'sequence', 'procedure'])
case('en_zh', 'current-instrument',
     'Under the music centre policy starting in July 2029, how long may a student borrow a practice violin?',
     '音乐中心自二〇二九年七月一日起执行新规：练习小提琴每次可借十四天，取代原先七天的借期。',
     '音乐中心旧规已于二〇二九年六月三十日结束：练习小提琴每次可借七天。',
     'The July 2029 effective date selects the fourteen-day rule, not the expired seven-day rule.',
     ['cross_language', 'temporal_version', 'numeric_constraint'])
case('en_zh', 'bicycle-squeal',
     'My bike brake squeals and the wheel rubs even when I am not braking. What needs adjusting?',
     '自行车未刹车时仍磨轮并伴有尖叫声，通常应检查刹车夹器是否居中，重新调整两侧刹车块间隙。',
     '自行车刹车手柄行程过长且无法有效减速时，应检查刹车线松紧并适当收紧线缆。',
     'Persistent rubbing without braking matches pad clearance and centring, not excessive lever travel.',
     ['cross_language', 'colloquial', 'paraphrase'])
case('en_zh', 'ppe-abbreviation',
     'Which PPE is required before using the glass-cutting bench?',
     '使用玻璃切割台前，个人防护装备必须包括护目镜和防割手套；普通布手套不能代替防割手套。',
     '使用纸张裁切台前，需保持台面整洁并戴普通工作手套。',
     'PPE maps to personal protective equipment, and the glass-cutting station has specific eyewear and cut-resistant glove requirements.',
     ['cross_language', 'abbreviation', 'semantic'])
case('en_zh', 'night-fair',
     'To run a stall using heating equipment at the hilltop night fair, which registration and fire-safety documents must I supply?',
     '山顶夜市摆摊登记：经营者必须提交临时摊位登记表，审核后安排摊位。',
     '山顶夜市游客可在入口领取地图，领取地图不代表取得摆摊资格。',
     'Registration and fire-safety evidence are two separately required documents, each covered by one relevant record.',
     ['cross_language', 'multi_relevant', 'conjunction'],
     positive2='山顶夜市安全要求：使用加热设备的摊位必须提交有效的灭火器检查记录，才可启用设备。')
case('en_zh', 'parcel-choice',
     'Which parcel service accepts a five-kilogram package and delivers within two working days?',
     '青鸟快递的急送服务接受六公斤以内包裹，承诺两个工作日内送达。',
     '青鸟快递的经济服务接受十公斤以内包裹，承诺五个工作日内送达。',
     'Only the express service meets both the five-kilogram acceptance and two-working-day delivery constraints.',
     ['cross_language', 'comparison', 'units'])
case('en_zh', 'subtitle-format',
     'Where should a .srt subtitle file go so the caption system imports it automatically?',
     '字幕系统监视 captions-in 文件夹，放入其中的 SRT 字幕文件会被自动导入。',
     '字幕系统的 transcript-review 文件夹只用于人工审阅文字转录稿，不会自动导入字幕。',
     'The SRT extension and automatic-import requirement select captions-in rather than the manual review folder.',
     ['cross_language', 'punctuation', 'file_format', 'lexical_anchor'])
case('en_zh', 'theatre-optout',
     'Can I stop theatre fundraising emails while keeping notifications about changes to my booked performance?',
     '剧院邮件偏好中，筹款推广与已购演出变更通知分别设置。关闭筹款推广并保留演出变更通知即可。',
     '剧院的取消全部邮件按钮会同时停止筹款推广和已购演出变更通知。',
     'Separate preference controls meet the selective opt-out request; cancelling all email would lose performance notices.',
     ['cross_language', 'negation_exception', 'conjunction'])
case('en_zh', 'suitcase-repair',
     'One suitcase wheel is jammed, but the shell and mounting are intact. Does the whole case need replacing?',
     '行李箱维修指引：箱体和轮座完好、只有轮子卡住时，清除轴上缠绕物并润滑轮轴，无需更换整个箱子。',
     '行李箱维修指引：轮座连接处的箱壳大面积开裂时，应更换箱体，单独润滑轮轴无法修复开裂。',
     'The intact shell and mount select wheel maintenance, not replacement for structural damage.',
     ['cross_language', 'conditional', 'paraphrase'])
case('en_zh', 'quarantine-scope',
     'Are visitors allowed to feed animals inside the rescue centre quarantine area?',
     '动物救助中心隔离区禁止访客投喂，所有食物由工作人员按隔离方案发放。',
     '动物救助中心互动区允许访客使用现场提供的饲料投喂指定动物。',
     'The quarantine-area prohibition answers the question; permission in the separate interactive area does not answer it.',
     ['cross_language', 'scope', 'negation_exception'])


def write():
    docs, queries, audit = [], [], []
    for i, c in enumerate(CASES, 1):
        qlang, dlang = c['group'].split('_')
        stem = f"holdout-{i:03d}-{c['slug']}"
        def doc_id(role):
            return 'holdout-doc-' + hashlib.sha256(f'neutral-id-v1:{stem}:{role}'.encode()).hexdigest()[:12]
        expected = [doc_id('positive')]
        dmeta = {'language': dlang, 'source': 'synthetic-author-v1', 'case_id': stem}
        docs.append({'type': 'doc', 'doc_id': expected[0], 'text': c['positive'], 'metadata': dmeta})
        if c['positive2']:
            expected.append(doc_id('positive-2'))
            docs.append({'type': 'doc', 'doc_id': expected[-1], 'text': c['positive2'], 'metadata': dmeta})
        nid = doc_id('negative')
        docs.append({'type': 'doc', 'doc_id': nid, 'text': c['negative'], 'metadata': dmeta})
        tags = sorted(set([c['group'], 'independent_holdout', *c['tags']]))
        query = {'type': 'query', 'id': stem, 'query': c['query'], 'expected': expected,
                 'suite': 'semantic', 'tags': tags, 'query_language': qlang,
                 'relevant_document_language': dlang, 'label_rationale': c['reason'],
                 'hard_negatives': [nid], 'case_family': c['slug']}
        queries.append(query)
        audit.append({'query_id': stem, 'positive_ids': expected, 'hard_negative_ids': [nid],
                      'rationale': c['reason'], 'authorship': 'synthetic manual AI author; no model score access'})
    assert len(CASES) == 64
    assert Counter(c['group'] for c in CASES) == dict.fromkeys(['en_en','zh_zh','zh_en','en_zh'],16)
    # Stable corpus shuffle prevents all positives occupying the first position
    # inside each local topic pair. This is not randomized relevance labelling.
    docs.sort(key=lambda r: hashlib.sha256(('corpus-order-v1:' + r['doc_id']).encode()).hexdigest())
    path = ROOT / 'retrieval-holdout-v1.jsonl'
    path.write_text(''.join(json.dumps(r, ensure_ascii=False, separators=(',', ':'))+'\n' for r in [*docs,*queries]), encoding='utf-8')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = {
        'dataset_id': 'tenant-rag-independent-synthetic-retrieval-holdout',
        'version': '1', 'sha256': digest, 'documents': len(docs), 'queries': len(queries),
        'frozen_at_utc': '2026-11-05T08:55:34Z',
        'provenance': 'New synthetic fixtures authored by a separate AI worker on 2026-11-05 without access to retrieval scores, tuning outcomes, embedding outputs, private data, or the existing query text. The worker inspected only loader/schema and the operations-v1 manifest. No external factual claims or customer data are used.',
        'label_policy': 'A record is relevant only when it directly answers a requested part under every explicit scope, intent, date, and condition. A topic match with the wrong condition is non-relevant. Four multi-part queries each have two positive documents. Every query lists a close negative and its label rationale. AI audit is not independent human adjudication.',
        'annotation_review': {'type': 'independent AI model-blind review', 'queries_reviewed': 64, 'documents_reviewed': 132, 'status': 'All requested corrections applied and independently rechecked before any retrieval evaluation.', 'no_human_adjudication': True},
        'intended_use': 'One-time held-out comparison after development-set fusion parameters are frozen; never choose fusion weights, tokenization, or ranking rules using these results. After inspection/use, this version is a public regression fixture, not a fresh blind benchmark.',
        'language_groups': {g: 16 for g in ['en_en', 'zh_zh', 'zh_en', 'en_zh']},
        'split_unit': 'Separate corpus and query set, not a random split of prior fixtures. Same 16 challenge families recur across groups with different entities and facts; queries are therefore not IID samples.',
        'limitations': ['Synthetic and author-coupled query/passage wording; not a representative production sample.', '64 queries in one small shared corpus; four language groups each contain only 16 queries.', 'One deliberately close negative per query and many unrelated distractors; not realistic large-corpus prevalence.', 'Only English and Simplified Chinese, mostly short operational rules, no noisy OCR, long-document chunking or unanswerable queries.', 'Labels receive AI review only, not independently recruited human adjudication.', 'Any apparent language-group difference is confounded by distinct subject matter and numeric facts; do not claim a controlled translation experiment.'],
        'freeze_policy': 'Hash fixed after model-blind annotation review and before evaluation. Correct factual label errors only in a newly versioned dataset, documenting whether prior results were observed.',
    }
    (ROOT/'retrieval-holdout-v1.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (ROOT/'retrieval-holdout-v1.labels.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'path': str(path), 'sha256': digest, 'docs':len(docs),'queries':len(queries),'groups':manifest['language_groups']},ensure_ascii=False))


if __name__ == '__main__':
    write()
