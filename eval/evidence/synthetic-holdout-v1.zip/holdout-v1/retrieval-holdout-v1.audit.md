# Annotation audit and freeze record

- Author: separate AI worker, blind to retrieval/tuning results.
- Reviewer: second AI worker, blind to retrieval/tuning results.
- Initial review: all 64 queries against all 132 documents, including expected
  labels, close negatives, cross-document completeness, language metadata, and
  companion-label consistency.
- Review corrections were completed before any retrieval run. No labels were
  altered in response to a model success or failure.
- Final freeze time: 2026-11-05 08:55:34 UTC.
- Final JSONL SHA-256:
  `7d876228830d398f52dff1366be34be69445bcb990e18440b598f0dbeb556853`

## Corrections before freeze

1. Query 011 now specifies a food stall, matching the food-handling certificate
   condition in its second relevant record.
2. Query 043 now specifies use of site electricity, matching the inspection
   certificate condition in its second relevant record.
3. Query 059 now specifies use of heating equipment, matching the extinguisher
   inspection condition in its second relevant record.
4. Query 060 now asks for two working days, not two unspecified calendar days.
5. Query 044 and its documents use empty coolbox weights consistently. A full
   container's weight did not establish its partially loaded weight. The new
   facts make both alternatives' eligibility determinate.
6. Query 028 explicitly requires the full 100-centimetre-wide base of the device
   to be supported by the worktop, excluding an unstated allowance for overhang.
7. Query 001's rationale now clearly says that 36 hours is less than the required
   48 hours of advance notice, instead of using ambiguous wording about a window.
8. Scope-negative records for queries 016, 032, 048, 058, and 064 no longer
   mention the positive record's scope. This avoids partial-answer disputes.
9. Document IDs are deterministic neutral hashes, without positive/negative
   suffixes. All references and companion labels were regenerated consistently.

The reviewer rechecked the changed cases, all 64 reference mappings, coverage
of all 132 documents, neutral IDs, label-file consistency, and the final hash.
No further errors were identified. This is AI review, not human adjudication or
a measured inter-annotator agreement study.

## Static validation

Passed against the project's existing `load_golden` and `dataset_manifest`:

- 132 document IDs and texts are unique; 64 query IDs and texts are unique.
- Expected and negative IDs exist and do not overlap within a query.
- All 64 mappings agree with the companion label file.
- All query/document language metadata agree with script-presence checks.
- All four language groups contain 16 queries.
- Four queries each contain two positive documents; 60 contain one.
- Maximum document length is 170 Unicode code points.
- Manifest SHA-256 matches the exact JSONL file.

Static checks and annotation review do not establish retrieval performance.
No embeddings, retrievals, or fusion scores were computed by the author or
annotation reviewer.
