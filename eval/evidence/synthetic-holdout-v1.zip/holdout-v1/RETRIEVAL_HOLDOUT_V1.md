# Model-blind synthetic retrieval holdout v1

## What this is

This is an independently authored **AI-synthetic** retrieval challenge set for
`tsumon/tenant-rag`, not a human-labelled benchmark and not a claim about
production quality. Every rule, organisation, date, and numerical fact is
invented. No customer records or other private information are present.

The author did not view retrieval rankings, embedding outputs, fusion tuning
results, existing query text, or model-generated answers. Only the existing
JSONL loader/schema and the earlier dataset's provenance manifest were read.
A second AI worker reviewed all labels and rechecked the corrections without
seeing any retrieval results. This
separation is a procedural blind, not a statistical guarantee of independence.

## Contents

- 132 documents, 64 questions, all in the `semantic` suite.
- 16 English→English, 16 Chinese→Chinese, 16 Chinese→English, and 16
  English→Chinese questions.
- Each question has one deliberately close negative. Four multipart questions
  each have two relevant documents; the other 60 each have one.
- The 16 challenge families include deadlines, conjunctive eligibility, exact
  identifiers, incident response, units/duration, return exceptions, procedural
  order, historical/current rules, colloquial paraphrases, abbreviations,
  multipart evidence, numerical comparisons, file extensions, selective
  notification choices, conditional repair rules, and location-specific rules.
- Four of the 32 cross-language questions deliberately retain a code or file
  extension as a lexical anchor. They must not be described as zero-overlap
  translation challenges. `lexical_anchor` marks these questions.
- Corpus ordering is fixed by a deterministic hash independent of relevance.
  All query examples compete against the complete shared 132-document corpus.

## Files

- `retrieval-holdout-v1.jsonl`: loader-compatible corpus and questions.
- `retrieval-holdout-v1.manifest.json`: exact corpus SHA-256, provenance, label
  policy, language-group counts, intended use, and limitations.
- `retrieval-holdout-v1.labels.json`: all positive/negative references and a
  per-question explanation of relevance.
- `author_holdout.py`: readable authored source and deterministic serializer.
- `retrieval-holdout-v1.audit.md`: pre-freeze review findings, corrections,
  independent AI recheck, and static validation record.

The manifest hash pins the exact UTF-8 bytes. Keep JSONL and manifest together.
The authoring script contains the same labels, so exclude it from any process
that must remain blind to test labels.

## Relevance policy

A document is relevant only if it directly supplies a requested part under
the question's full intent, entity, scope, date, and conditions. A topical
match that concerns a different operation or violates a required condition is
not relevant. For example, a cancellation deadline does not answer a change
deadline, and a larger carrying capacity does not make a too-tall vehicle a
valid choice. Negative examples sometimes supply nearby facts, but must not
themselves directly answer a requested part.

All questions are answerable using their expected records. This dataset does
not test abstention, unanswerable questions, or answer-generation faithfulness.
Closed-world relevance applies to this synthetic corpus only.

## Evaluation protocol

1. Tune fusion and any preprocessing solely on a separate development set.
2. Freeze the candidate strategies, weights, tokenization, retrieval depth,
   embedding model/snapshot, and metric implementation before the first held-out
   run. Record their identifiers and the dataset SHA-256.
3. Evaluate all fixed candidates together once. Report the full held-out result,
   including regressions, rather than selecting a convenient subset.
4. Break out all four language groups and same-language versus cross-language
   groups. Also report code/file-format anchor cases and multi-positive cases
   where useful. Report recall and rank quality separately; their denominators
   differ for the four multi-positive questions.
5. Inspect failures to diagnose the current approach, but do not revise the same
   strategy using this holdout and then call a rerun an independent test. Any
   such rerun is a development/regression result. A genuinely fresh confirmation
   needs new data that the strategy author has not inspected.
6. If a label error is discovered after evaluation, publish a new version with
   explicit correction history and disclose that outcomes were already seen.

## Limitations and interpretation

The 64 questions are not random samples of real user traffic. They are short,
clean, manually coupled query/passage examples made by one AI author. The same
16 challenge families recur across all four language groups, and the groups
use different subject matter and values, not matched translations. Treat
questions as correlated challenge cases; do not infer a general multilingual
quality difference or a causal effect of translation from group averages.

The shared corpus is small and mostly contains one close negative plus many
unrelated records for each topic. This is substantially easier and differently
distributed than a large tenant corpus with repeated entities, revisions,
near-duplicates, OCR noise, and long documents. Only English and Simplified
Chinese are covered. No human adjudication or inter-annotator agreement is
claimed.

There are only 16 examples per language group. A one-query change can shift a
binary success rate in a group by 6.25 percentage points. Report counts and
uncertainty where feasible; do not portray small score differences as proof of
robust superiority. Distinguish this model-blind synthetic holdout from a
representative external benchmark.

Once the examples or results are used to guide implementation, version 1
remains useful for regression checks but is no longer a fresh blind holdout.
